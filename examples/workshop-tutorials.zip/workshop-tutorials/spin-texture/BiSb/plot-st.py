#!/usr/bin/env python

import pyprocar

# Spin texture in Sx direction
pyprocar.fermi2D("PROCAR", outcar="OUTCAR", st=True, energy=-1, spin=1, noarrow=True)

# Plotting with arrows
pyprocar.fermi2D("PROCAR", outcar="OUTCAR", st=True, energy=-1, spin=1, noarrow=False)
