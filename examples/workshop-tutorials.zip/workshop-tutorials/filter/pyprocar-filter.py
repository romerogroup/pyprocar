#!/usr/bin/env python

import pyprocar

# select bands
pyprocar.filter("PROCAR", "PROCAR-band50-70", bands=[50, 70])

# select orbitals
pyprocar.filter("PROCAR", "PROCAR-filtered_sp", orbitals=[[0], [1, 2, 3]])
