#!/usr/bin/env python

import pyprocar

# Plotting PDOS of SrVO3

pyprocar.dosplot(
    filename="vasprun.xml",
    mode="stack",
    colors=["lawngreen", "orangered", "royalblue"],
    items=dict(Sr=[1, 2, 3], O=[1, 2, 3], V=[4, 5, 6, 7, 8]),
    orientation="horizontal",
    elimit=[-4, 4],
    plot_total=True,
)
