#!/usr/bin/env python

import pyprocar

# Spin magnetization
pyprocar.bandsplot(
    "PROCAR",
    outcar="OUTCAR.scf",
    kpointsfile="KPOINTS",
    elimit=[-6, 6],
    mode="parametric",
    spin=1,
    cmap="seismic",
    vmin=-1,
    vmax=1,
)

# spin up
pyprocar.bandsplot(
    "PROCAR",
    outcar="OUTCAR.scf",
    kpointsfile="KPOINTS",
    elimit=[-6, 6],
    mode="parametric",
    spin=0,
    separate=True,
    cmap="seismic",
    vmin=0,
    vmax=1,
)

# spin down
pyprocar.bandsplot(
    "PROCAR",
    outcar="OUTCAR.scf",
    kpointsfile="KPOINTS",
    elimit=[-6, 6],
    mode="parametric",
    spin=1,
    separate=True,
    cmap="seismic_r",
    vmin=0,
    vmax=1,
)
