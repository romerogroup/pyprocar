#!/usr/bin/env python

import pyprocar

# plain
pyprocar.bandsplot(
    "PROCAR",
    kpointsfile="KPOINTS",
    outcar="OUTCAR",
    elimit=[-6, 6],
    mode="plain",
)

# eg orbitals
pyprocar.bandsplot(
    "PROCAR",
    kpointsfile="KPOINTS",
    outcar="OUTCAR",
    elimit=[-6, 6],
    mode="parametric",
    orbitals=[6, 8],
    vmin=0,
    vmax=1,
)

# V atom
pyprocar.bandsplot(
    "PROCAR",
    kpointsfile="KPOINTS",
    outcar="OUTCAR",
    elimit=[-6, 6],
    mode="parametric",
    atoms=[1],
    vmin=0,
    vmax=1,
)

# t2g orbital of V atom
pyprocar.bandsplot(
    "PROCAR",
    kpointsfile="KPOINTS",
    outcar="OUTCAR",
    elimit=[-6, 6],
    mode="parametric",
    atoms=[1],
    orbitals=[4, 5, 7],
    vmin=0,
    vmax=1,
)
