#!/usr/bin/env python

import pyprocar

# Stot
pyprocar.bandsplot(
    "PROCAR",
    outcar="OUTCAR.scf",
    kpointsfile="KPOINTS",
    elimit=[-2, 2],
    mode="parametric",
    spin=0,
    cmap="seismic",
)

# Sx
pyprocar.bandsplot(
    "PROCAR",
    outcar="OUTCAR.scf",
    kpointsfile="KPOINTS",
    elimit=[-2, 2],
    mode="parametric",
    spin=1,
    cmap="seismic",
)

# Sy
pyprocar.bandsplot(
    "PROCAR",
    outcar="OUTCAR.scf",
    kpointsfile="KPOINTS",
    elimit=[-2, 2],
    mode="parametric",
    spin=2,
    cmap="seismic",
)
